export interface RequestModelObtenerReporte
    {
        SosId : number;
    }