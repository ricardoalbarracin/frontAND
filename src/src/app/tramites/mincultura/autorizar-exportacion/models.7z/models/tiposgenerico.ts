export interface Tiposgenerico
    {
        Id : number;
        Valor : string;
    }