export interface RequestModelObtenerListaDeterioro
    {
        IdFicha : number;
        IdPrestamo : number;
    }