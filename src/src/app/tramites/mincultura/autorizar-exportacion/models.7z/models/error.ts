export interface Error
    {
        Code : string;
        Description : string;
    }