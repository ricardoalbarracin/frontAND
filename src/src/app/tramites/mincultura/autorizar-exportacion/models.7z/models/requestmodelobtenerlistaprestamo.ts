export interface RequestModelObtenerListaPrestamo
    {
        SosId : number;
        IdFicha : number;
        IdPrestamo : number;
    }