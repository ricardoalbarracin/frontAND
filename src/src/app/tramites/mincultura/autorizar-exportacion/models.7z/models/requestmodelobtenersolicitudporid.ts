export interface RequestModelObtenerSolicitudPorId
    {
        SosId : number;
    }