export interface ReturnModelObtenerTiposBasPersonas 
    {

        Paises : object;
        ZonasGeograficas : object;
        ZonaGeografica : object;
        TiposDocumentos : object;
        TiposEpocas : object;
        TiposTecnicas : object;
        TiposPersonas : Tipospersona[];
        TiposMotivos : object;
        TiposRespuestas : object;
        TiposGenericos : object;
        Success : boolean;
        Errors : Error;
    }

    export interface Tipospersona
    {
        TIP_TIPO_PERSONA : number;
        TIP_NOMBRE : string;
    }