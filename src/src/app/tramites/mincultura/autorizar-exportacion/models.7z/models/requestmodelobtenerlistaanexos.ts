export interface RequestModelObtenerListaAnexos
    {
        SosId : number;
    }