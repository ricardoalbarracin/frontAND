export interface RequestModelObtenerObras
    {
        SosId : number;
    }