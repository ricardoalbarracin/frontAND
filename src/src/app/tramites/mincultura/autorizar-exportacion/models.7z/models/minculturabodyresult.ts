export interface MintCulturaBodyResult
    {
        Mensaje : string;

        OperacionExitosa : boolean;

        
    }
