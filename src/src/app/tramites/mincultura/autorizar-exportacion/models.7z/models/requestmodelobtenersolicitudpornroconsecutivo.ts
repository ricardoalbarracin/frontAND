export interface RequestModelObtenerSolicitudPorNroConsecutivo
    {
        NroConsecutivo : string;
    }