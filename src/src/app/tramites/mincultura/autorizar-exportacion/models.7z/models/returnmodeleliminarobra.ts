import  {Fichatecnicabienes} from './fichatecnicabienes';
export interface ReturnModelElimintarObra 
    {

    
        FichaTecnicaBienes : Fichatecnicabienes;
        Success : boolean;
        Errors : Error;
    }