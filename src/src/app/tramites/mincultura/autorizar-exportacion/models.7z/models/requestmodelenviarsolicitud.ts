export interface RequestModelEnviarSolicitud
    {
        SosId : string;
    }
