export interface RequestModelObtenerSolicitudes
    {
        FechaRadicacioninticial : string;
        FechaRadicacionFintal : string;
        NroDocumentoSolicitante : string;
        NroConsecutivo : object;
        Estado : string;
    }