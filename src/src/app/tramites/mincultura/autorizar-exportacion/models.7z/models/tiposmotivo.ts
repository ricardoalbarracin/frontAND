export interface Tiposmotivo
    {
        PAT_SOLICITUD_SALIDA_OBRAS : object[];
        TMS_ID : number;
        TMS_NOMBRE : string;
        TMS_ESTADO : string;
    }