export interface RequestModelObtenerListaConceptosObras
    {
        SosId : number;
        IdFicha : number;
        IdConcepto : number;
    }