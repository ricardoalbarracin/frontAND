export interface RequestModelElimintarObra
    {
        FicId : number;
    }