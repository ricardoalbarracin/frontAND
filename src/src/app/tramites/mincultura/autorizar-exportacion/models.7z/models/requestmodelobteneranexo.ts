export interface RequestModelObtenerAnexo
    {
        IdAnexo : number;
    }